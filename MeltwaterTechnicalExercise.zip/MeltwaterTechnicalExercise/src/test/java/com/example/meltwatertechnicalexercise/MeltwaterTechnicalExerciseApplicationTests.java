package com.example.meltwatertechnicalexercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeltwaterTechnicalExerciseApplicationTests {

    @Test
    void contextLoads() {
    }

}
